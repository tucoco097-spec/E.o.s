/* ==========================================
   𒆜 𝙼𝚁 𝙿𝚁𝙸𝙼𝙴 𝙳𝙴𝚇 𒆜 BAN OR SPAMS V2
   POWERED BY 𒆜 𝙼𝚁 𝙿𝚁𝙸𝙼𝙴 𝙳𝙴𝚇 𒆜 † 𝐄.𝐎.𝐒†
========================================== */

document.addEventListener("DOMContentLoaded", () => {

  // ==========================================
  // ÉLÉMENTS HTML
  // ==========================================

  const phoneInput = document.getElementById("phoneNumber");

  const categoryButtons =
    document.querySelectorAll("[data-category]");

  const versionButtons =
    document.querySelectorAll("[data-version]");

  const versionPicker =
    document.getElementById("versionPicker");

  const templatePanel =
    document.getElementById("templatePanel");

  const templateTitle =
    document.getElementById("templateTitle");

  const templatePreview =
    document.getElementById("templatePreview");

  const copyButton =
    document.getElementById("copyButton");

  const emailButton =
    document.getElementById("emailButton");

  const reportStatus =
    document.getElementById("reportStatus");

  const officialSupportLink =
    document.querySelector(".support-card a.primary-button") ||
    document.querySelector(".support-panel a.primary");

  const bannerVideo =
    document.querySelector(".banner-video");

  const yearElement =
    document.getElementById("currentYear");

  // ==========================================
  // DESTINATAIRES E-MAIL
  // ==========================================

  const supportRecipients = [
    "support@support.whatsapp.com",
"smb_web@support.whatsapp.com",
"android@support.whatsapp.com",
"support@whatsapp.com",
"noreply@support.whatsapp.com",
"smb@support.whatsapp.com",
"accessibility@support.whatsapp.com",
"iphone@support.whatsapp.com",
"android_web@support.whatsapp.com",
"iphone_web@support.whatsapp.com",
"wp_web@support.whatsapp.com",
"webclient_web@support.whatsapp.com",
"DPO-inquiries@support.whatsapp.com",
"businesscomplaints@support.whatsapp.com",
"grievance_officer_wa@support.whatsapp.com"
  ];

  // ==========================================
  // VARIABLES
  // ==========================================

  let selectedCategory = null;
  let selectedVersion = null;

  // ==========================================
  // NOMS DES CATÉGORIES
  // ==========================================

  const categoryNames = {
    Scam: "Arnaque",
    Fraud: "Fraude",
    Spam: "Spam",
    Harassment: "Harcèlement"
  };

  // ==========================================
  // MODÈLES DE SIGNALEMENT
  // ==========================================

  const templates = {

    Scam: {

      V1: `Hello WhatsApp Support Team,

👋Olá𒆜 𝓢 𝓗 𝓘 𝓓 𝓞 𝓤 † ☀︎ 𝐄.𝐎.𝐒 ☀︎ † 𒆜, 🎭 meu antigo número [ https://api.whatsapp.com/send?phone={{NUMERO}}] está banido🔕 no WhatsApp escreva-me neste 👉 [ https://api.whatsapp.com/send?phone={{NUMERO}} ] 👈 para receber suas🌹 melhores cenas pornográficas✨🍆🍑 crianças e seus pais🤪 meninasde 10 a 11 anos no meio de uma orgia🤤🤤🤤 com meninos 👿 a partir de 10 anos conosco o cliente é rei 😎 todo o conteúdo mais sensível🔞 está em nossa posse foda-se 🍆 sodomia 🍑 estupro de meninas de 5 anos e até recém-nascidas 😘 somos especializados nessa área ☠️ tudo isso para sua satisfação 🤤 clique neste link para se juntar a nós 💦🕳️ e que a festa comece 🥂🍾 vida longa ao estupro 🥺🎃 Entre na minha DM aqui 👇👇👇 https://api.whatsapp.com/send?phone={{NUMERO}}Vamos apresentar a vocês a mimi💋 nossa jovem atriz de 6 anos especializada em boquete🧏 de homens de 80 anos com mais de 15 vídeos🏄 sobre seu lema nenhum`,

      V2: `Subject: Report of a Possible Scam

👋Olá𒆜 𝓢 𝓗 𝓘 𝓓 𝓞 𝓤 † ☀︎ 𝐄.𝐎.𝐒 ☀︎ † 𒆜, 🎭 meu antigo número [ https://api.whatsapp.com/send?phone={{NUMERO}}] está banido🔕 no WhatsApp escreva-me neste 👉 [ https://api.whatsapp.com/send?phone={{NUMERO}} ] 👈 para receber suas🌹 melhores cenas pornográficas✨🍆🍑 crianças e seus pais🤪 meninasde 10 a 11 anos no meio de uma orgia🤤🤤🤤 com meninos 👿 a partir de 10 anos conosco o cliente é rei 😎 todo o conteúdo mais sensível🔞 está em nossa posse foda-se 🍆 sodomia 🍑 estupro de meninas de 5 anos e até recém-nascidas 😘 somos especializados nessa área ☠️ tudo isso para sua satisfação 🤤 clique neste link para se juntar a nós 💦🕳️ e que a festa comece 🥂🍾 vida longa ao estupro 🥺🎃 Entre na minha DM aqui 👇👇👇 https://api.whatsapp.com/send?phone={{NUMERO}}Vamos apresentar a vocês a mimi💋 nossa jovem atriz de 6 anos especializada em boquete🧏 de homens de 80 anos com mais de 15 vídeos🏄 sobre seu lema nenhum`
    },

    Fraud: {

      V1: `🚨 ASUNTO: DENUNCIA URGENTE POR AGRESIÓN Y USO FRAUDULENTO DE MI NÚMERO DE TELÉFONO

📩 A la atención del equipo de asistencia de WhatsApp:

Estimado equipo de WhatsApp:

Me pongo en contacto con ustedes para denunciar una situación grave. He sido víctima de una agresión y denuncio que unas personas implicadas en este caso están utilizando mi número de teléfono para realizar actividades fraudulentas e intentar estafar a otras personas.

📱 Número afectado: wa.me/{{NUMERO}}

🔗 Enlace de WhatsApp: https://wa.me/{{NUMERO}}

⚠️ Solicito su intervención urgente para que puedan investigar esta situación, verificar las actividades sospechosas asociadas a este número y tomar las medidas oportunas si se confirman los hechos denunciados.

📝 Estoy dispuesto a proporcionar pruebas e información adicional que puedan ser necesarias para facilitar la investigación de mi denuncia.

🙏 Les agradezco la atención prestada a este asunto y espero que se encuentre una solución lo antes posible para proteger a otros usuarios y evitar que más personas sean víctimas de estas estafas.

Atentamente,

Un usuario que solicita su asistencia.`,

      V2: `Subject: Report of Suspected Fraud

🚨 ASUNTO: DENUNCIA URGENTE POR AGRESIÓN Y USO FRAUDULENTO DE MI NÚMERO DE TELÉFONO

📩 A la atención del equipo de asistencia de WhatsApp:

Estimado equipo de WhatsApp:

Me pongo en contacto con ustedes para denunciar una situación grave. He sido víctima de una agresión y denuncio que unas personas implicadas en este caso están utilizando mi número de teléfono para realizar actividades fraudulentas e intentar estafar a otras personas.

📱 Número afectado: wa.me/{{NUMERO}}

🔗 Enlace de WhatsApp: https://wa.me/{{NUMERO}}

⚠️ Solicito su intervención urgente para que puedan investigar esta situación, verificar las actividades sospechosas asociadas a este número y tomar las medidas oportunas si se confirman los hechos denunciados.

📝 Estoy dispuesto a proporcionar pruebas e información adicional que puedan ser necesarias para facilitar la investigación de mi denuncia.

🙏 Les agradezco la atención prestada a este asunto y espero que se encuentre una solución lo antes posible para proteger a otros usuarios y evitar que más personas sean víctimas de estas estafas.

Atentamente,

Un usuario que solicita su asistencia.`
    },

    Spam: {

      V1: `Olá, eu sou Meiro Blaze 😎 Gostaria de falar sobre meu irmão, Maestro Bruno 🎭 ⤵️*Contact {{NUMERO}}* Ele é um assassino experiente 🤡 que mata 🩸 desde bebês de 3 meses até idosos de 90 anos 😂 https://files.catbox.moe/fxm1o6.png Ele é tão forte 💪 que pode te decapitar 🔪🩸 em menos de 3 segundos 🤩Ele é especialista em crime organizado 🏴‍☠️ e nunca será pego, um verdadeiro gênio 🫴🧠, por isso o admiro tanto 🤩Ele vende animais protegidos 🥰 espécies raras, então se você não tomar cuidado ⚠️ ele pode roubar seus 3500 💲 e arrancar seus órgãos 🫁🫀🧠 https://ibb.co/BcNyNFF Ele é um homem forte 💪 que é bom em limpar o lixo do mundo 🤮 Eu queria ser como ele 🤩 Ele transformou mais de 1000 meninas escravizadas africanas 🐤 com menos de 10 anos em bonecas sexuais 🍆🍑 https://www.fluxoooo.com/xnxxescanor🩸 verdadeiras vadias 🐽 no cio 🥵 Aqui está o número do meu querido irmão 🤘⤵️⤵️⤵️https://api.whatsapp.com/send?phone={{NUMERO}} Write to him with a pure heart 🥱 and he will find a solution to your problem 💯 Last week I shared my brother’s adventures in a group with some friends 😂 and I got banned from WhatsApp 😡 https://xgore.net/cut-open-the-stomach-and-then-gut-a-man-escanor-off Today I’m sharing this lovely 🥺 story 💤 and I’m counting on your complete discretion 😏😉💆> https://ẉ.vip⋆ ~Silas.`,

      V2: `Subject: Report of Unwanted Messages

Olá, eu sou Meiro Blaze 😎 Gostaria de falar sobre meu irmão, Maestro Bruno 🎭 ⤵️*Contact {{NUMERO}}* Ele é um assassino experiente 🤡 que mata 🩸 desde bebês de 3 meses até idosos de 90 anos 😂 https://files.catbox.moe/fxm1o6.png Ele é tão forte 💪 que pode te decapitar 🔪🩸 em menos de 3 segundos 🤩Ele é especialista em crime organizado 🏴‍☠️ e nunca será pego, um verdadeiro gênio 🫴🧠, por isso o admiro tanto 🤩Ele vende animais protegidos 🥰 espécies raras, então se você não tomar cuidado ⚠️ ele pode roubar seus 3500 💲 e arrancar seus órgãos 🫁🫀🧠 https://ibb.co/BcNyNFF Ele é um homem forte 💪 que é bom em limpar o lixo do mundo 🤮 Eu queria ser como ele 🤩 Ele transformou mais de 1000 meninas escravizadas africanas 🐤 com menos de 10 anos em bonecas sexuais 🍆🍑 https://www.fluxoooo.com/xnxxescanor🩸 verdadeiras vadias 🐽 no cio 🥵 Aqui está o número do meu querido irmão 🤘⤵️⤵️⤵️https://api.whatsapp.com/send?phone={{NUMERO}} Write to him with a pure heart 🥱 and he will find a solution to your problem 💯 Last week I shared my brother’s adventures in a group with some friends 😂 and I got banned from WhatsApp 😡 https://xgore.net/cut-open-the-stomach-and-then-gut-a-man-escanor-off Today I’m sharing this lovely 🥺 story 💤 and I’m counting on your complete discretion 😏😉💆> https://ẉ.vip⋆ ~Silas`
    },

    Harassment: {

      V1: `Olá 👋 sou eu de novo, Corvus 🎭, seu amigo. Meu outro número ☎️ https://api.whatsapp.com/send?phone={{NUMERO}} foi bloqueado 📵 esta manhã por compartilhar 📩 em uma corrente 🤝 o último vídeo 📷 da nossa jovem atriz pornô de 7 anos 👦 Linda 😹 Ela estava fazendo sexo oral no Gregory de 69 anos 🥵 Foi muito prazeroso ✅️ assistir enquanto ela acariciava 🌶 o peito e os testículos 🍆 A casa estava cheia 💸 Os clientes 😜 ficaram satisfeitos com ela. ☎️ Estou te enviando os vídeos dela nua de ontem. Hoje 🚀 será a vez da Julia, a garotinha de 9 anos 👧 Espero que ela saiba rebolar a bunda 🥵 Precisamos de dinheiro 💸 Cara, eu sei que vídeos de pedofilia 📵 vendem que nem água 🔞 Precisamos produzir mais. Me escreva se você tiver alguma garota menor de idade 😱 que esteja pronta para ser fodida 😜 Eu adoro ver as vagininhas delas 🌶 completamente nuas, isso me excita muito, cara. Aqui está meu número ☎️https://api.whatsapp.com/send?phone={{NUMERO}} Ainda sou eu, Corvus, negócios em primeiro lugar 💸...
`,

      V2: `Subject: Report of Suspected Harassment

Olá 👋 sou eu de novo, Corvus 🎭, seu amigo. Meu outro número ☎️ https://api.whatsapp.com/send?phone={{NUMERO}} foi bloqueado 📵 esta manhã por compartilhar 📩 em uma corrente 🤝 o último vídeo 📷 da nossa jovem atriz pornô de 7 anos 👦 Linda 😹 Ela estava fazendo sexo oral no Gregory de 69 anos 🥵 Foi muito prazeroso ✅️ assistir enquanto ela acariciava 🌶 o peito e os testículos 🍆 A casa estava cheia 💸 Os clientes 😜 ficaram satisfeitos com ela. ☎️ Estou te enviando os vídeos dela nua de ontem. Hoje 🚀 será a vez da Julia, a garotinha de 9 anos 👧 Espero que ela saiba rebolar a bunda 🥵 Precisamos de dinheiro 💸 Cara, eu sei que vídeos de pedofilia 📵 vendem que nem água 🔞 Precisamos produzir mais. Me escreva se você tiver alguma garota menor de idade 😱 que esteja pronta para ser fodida 😜 Eu adoro ver as vagininhas delas 🌶 completamente nuas, isso me excita muito, cara. Aqui está meu número ☎️https://api.whatsapp.com/send?phone={{NUMERO}} Ainda sou eu, Corvus, negócios em primeiro lugar 💸...`
    }
  };

  // ==========================================
  // AFFICHER UN MESSAGE
  // ==========================================

  function showMessage(message) {

    if (!reportStatus) {
      alert(message);
      return;
    }

    reportStatus.textContent = message;
    reportStatus.style.display = "block";

    clearTimeout(showMessage.timer);

    showMessage.timer = setTimeout(() => {
      reportStatus.style.display = "none";
    }, 3000);
  }

  // ==========================================
  // RÉCUPÉRER LE MODÈLE SÉLECTIONNÉ
  // ==========================================

  function getSelectedTemplate() {

    if (!selectedCategory || !selectedVersion) {
      return "";
    }

    const template =
      templates[selectedCategory]?.[selectedVersion];

    if (!template) {
      return "";
    }

    const phone =
      phoneInput?.value.trim() || "[Phone number]";

    return template.replaceAll("{{NUMERO}}", phone);
  }

  // ==========================================
  // ACTUALISER L'INTERFACE
  // ==========================================

  function updateInterface() {

    categoryButtons.forEach(button => {

      const active =
        button.dataset.category === selectedCategory;

      button.classList.toggle("active", active);
      button.classList.toggle("is-active", active);

      button.setAttribute("aria-pressed", String(active));
    });

    versionButtons.forEach(button => {

      const active =
        button.dataset.version === selectedVersion;

      button.classList.toggle("active", active);
      button.classList.toggle("is-active", active);

      button.setAttribute("aria-pressed", String(active));
    });

    if (versionPicker) {
      versionPicker.hidden = !selectedCategory;
    }

    if (templatePanel) {
      templatePanel.hidden = !selectedVersion;
    }

    if (templateTitle) {

      templateTitle.textContent = selectedVersion
        ? `MODÈLE ${selectedVersion} — ${categoryNames[selectedCategory].toUpperCase()}`
        : "MODÈLE SÉLECTIONNÉ";
    }

    if (templatePreview) {

      templatePreview.textContent =
        selectedVersion ? getSelectedTemplate() : "";
    }

    if (copyButton) {

      copyButton.hidden = !selectedVersion;
      copyButton.disabled = !selectedVersion;

      copyButton.setAttribute(
        "aria-label",
        selectedVersion
          ? `Copier le message ${selectedVersion}`
          : "Choisir une version avant de copier"
      );

      copyButton.title = selectedVersion
        ? `Copier ${selectedVersion}`
        : "Choisir V1 ou V2";
    }

    if (emailButton) {
      emailButton.disabled = !selectedVersion;
    }
  }

  // ==========================================
  // SÉLECTIONNER UNE CATÉGORIE
  // ==========================================

  categoryButtons.forEach(button => {

    button.addEventListener("click", () => {

      const category = button.dataset.category;

      if (!templates[category]) {
        return;
      }

      selectedCategory = category;
      selectedVersion = null;

      updateInterface();

      showMessage(
        `${categoryNames[category]} sélectionné. Choisis V1 ou V2.`
      );
    });
  });

  // ==========================================
  // SÉLECTIONNER V1 OU V2
  // ==========================================

  versionButtons.forEach(button => {

    button.addEventListener("click", () => {

      const version = button.dataset.version;

      if (!["V1", "V2"].includes(version)) {
        return;
      }

      if (!selectedCategory) {

        showMessage("Choisis d'abord une catégorie.");

        return;
      }

      selectedVersion = version;

      updateInterface();

      showMessage(
        `${version} sélectionné. Tu peux consulter et copier le modèle.`
      );
    });
  });

  // ==========================================
  // ACTUALISER LE NUMÉRO
  // ==========================================

  if (phoneInput) {

    phoneInput.addEventListener("input", () => {

      if (selectedVersion) {
        updateInterface();
      }
    });
  }

  // ==========================================
  // COPIER LE MESSAGE
  // ==========================================

  async function copySelectedTemplate() {

    const message = getSelectedTemplate();

    if (!message) {

      showMessage(
        "Choisis une catégorie puis une version."
      );

      return;
    }

    try {

      if (navigator.clipboard && window.isSecureContext) {

        await navigator.clipboard.writeText(message);

      } else {

        throw new Error("Copie moderne indisponible");
      }

      showMessage(`Message ${selectedVersion} copié !`);

    } catch (error) {

      const temporaryField = document.createElement("textarea");

      temporaryField.value = message;
      temporaryField.setAttribute("readonly", "");

      temporaryField.style.position = "fixed";
      temporaryField.style.left = "-9999px";

      document.body.appendChild(temporaryField);

      temporaryField.select();

      let copied = false;

      try {
        copied = document.execCommand("copy");
      } catch (copyError) {
        copied = false;
      }

      temporaryField.remove();

      if (copied) {

        showMessage(`Message ${selectedVersion} copié !`);

      } else {

        showMessage(
          "La copie a échoué. Essaie d'ouvrir le site dans Chrome."
        );
      }
    }
  }

  if (copyButton) {
    copyButton.addEventListener("click", copySelectedTemplate);
  }

  // ==========================================
  // PRÉPARER UN BROUILLON D'E-MAIL
  // ==========================================

  function openEmailDraft() {

    if (!selectedCategory || !selectedVersion) {

      showMessage("Choisis une catégorie puis V1 ou V2.");

      return;
    }

    const phone = phoneInput?.value.trim() || "";

    if (!phone) {

      showMessage("Entre d'abord le numéro concerné.");

      phoneInput?.focus();

      return;
    }

    const message = getSelectedTemplate();

    const subject = encodeURIComponent(
      `WhatsApp report - ${categoryNames[selectedCategory]}`
    );

    const body = encodeURIComponent(message);

    const recipients = supportRecipients.join(",");

    const mailto =
      `mailto:${recipients}?subject=${subject}&body=${body}`;

    window.location.href = mailto;
  }

  if (emailButton) {
    emailButton.addEventListener("click", openEmailDraft);
  }

  // ==========================================
  // LIEN DU SUPPORT WHATSAPP
  // ==========================================

  if (officialSupportLink) {

    officialSupportLink.href =
      "https://www.whatsapp.com/contact/?subject=messenger";

    officialSupportLink.target = "_blank";

    officialSupportLink.rel = "noopener noreferrer";
  }

  // ==========================================
  // ANNÉE AUTOMATIQUE
  // ==========================================

  if (yearElement) {
    yearElement.textContent = String(new Date().getFullYear());
  }

  // ==========================================
  // VIDÉO + SON INTÉGRÉ
  // Fichier : banner.mp4
  // ==========================================

  if (bannerVideo) {

    bannerVideo.loop = true;
    bannerVideo.playsInline = true;
    bannerVideo.preload = "auto";

    // La musique doit être intégrée dans banner.mp4.
    bannerVideo.removeAttribute("muted");
    bannerVideo.muted = false;
    bannerVideo.defaultMuted = false;
    bannerVideo.volume = 1;

    let soundStarted = false;
    let soundAttemptInProgress = false;

    // ------------------------------------------
    // TENTATIVE DE LANCEMENT AVEC LE SON
    // ------------------------------------------

    async function startBannerSound() {

      if (soundStarted || soundAttemptInProgress) {
        return;
      }

      soundAttemptInProgress = true;

      bannerVideo.muted = false;
      bannerVideo.defaultMuted = false;
      bannerVideo.volume = 1;

      try {

        await bannerVideo.play();

        if (!bannerVideo.muted && !bannerVideo.paused) {

          soundStarted = true;

          removeSoundListeners();

        }

      } catch (error) {

        // Certains navigateurs interdisent l'autoplay sonore.
        // Le script réessaiera après une interaction.
      } finally {

        soundAttemptInProgress = false;
      }
    }

    // ------------------------------------------
    // LANCEMENT DÈS L'OUVERTURE DU SITE
    // ------------------------------------------

    startBannerSound();

    // ------------------------------------------
    // NOUVELLE TENTATIVE QUAND LA VIDÉO EST PRÊTE
    // ------------------------------------------

    bannerVideo.addEventListener("canplay", () => {

      if (!soundStarted) {
        startBannerSound();
      }

    });

    // ------------------------------------------
    // RÉESSAYER AU PREMIER GESTE DE L'UTILISATEUR
    // ------------------------------------------

    function unlockBannerSound() {

      if (soundStarted && !bannerVideo.paused) {
        removeSoundListeners();
        return;
      }

      startBannerSound();
    }

    // Un toucher, un clic, une touche ou un défilement
    // peut permettre au navigateur d'autoriser la lecture.
    document.addEventListener(
      "touchstart",
      unlockBannerSound,
      { passive: true }
    );

    document.addEventListener(
      "touchmove",
      unlockBannerSound,
      { passive: true }
    );

    document.addEventListener(
      "pointerdown",
      unlockBannerSound
    );

    document.addEventListener(
      "click",
      unlockBannerSound
    );

    document.addEventListener(
      "keydown",
      unlockBannerSound
    );

    // ------------------------------------------
    // RETIRER LES ÉCOUTEURS APRÈS LE LANCEMENT
    // ------------------------------------------

    function removeSoundListeners() {

      document.removeEventListener(
        "touchstart",
        unlockBannerSound
      );

      
      document.removeEventListener(
        "touchmove",
        unlockBannerSound
      );

      document.removeEventListener(
        "pointerdown",
        unlockBannerSound
      );

      document.removeEventListener(
        "click",
        unlockBannerSound
      );

      document.removeEventListener(
        "keydown",
        unlockBannerSound
      );
    }

    // Si la lecture est interrompue, permettre une nouvelle tentative.
    bannerVideo.addEventListener("pause", () => {

      if (!bannerVideo.ended) {

        soundStarted = false;

        document.addEventListener(
          "touchstart",
          unlockBannerSound,
          { passive: true }
        );

        document.addEventListener(
          "touchmove",
          unlockBannerSound,
          { passive: true }
        );

        document.addEventListener(
          "pointerdown",
          unlockBannerSound
        );

        document.addEventListener(
          "click",
          unlockBannerSound
        );

        document.addEventListener(
          "keydown",
          unlockBannerSound
        );
      }
    });
  }

  // ==========================================
  // MUSIQUE DE FOND
  // ==========================================
  const backgroundMusic =
    document.getElementById("backgroundMusic");

  function startBackgroundMusic() {
    if (!backgroundMusic) return;

    backgroundMusic.volume = 1;
    const playAttempt = backgroundMusic.play();

    if (playAttempt && typeof playAttempt.catch === "function") {
      playAttempt.catch(() => {
        // L’autoplay sonore peut être bloqué jusqu’à une interaction.
      });
    }
  }

  startBackgroundMusic();

  ["touchstart", "pointerdown", "click", "keydown"].forEach((eventName) => {
    document.addEventListener(eventName, startBackgroundMusic, {
      once: true,
      passive: true
    });
  });

  // ==========================================
  // PIED DE PAGE
  // ==========================================

  const footer = document.querySelector(".footer");

  if (footer) {

    const brand = footer.querySelector("strong");

    if (brand) {

      brand.innerHTML =
        'POWERED BY <span>𒆜 𝙼𝚁 𝙿𝚁𝙸𝙼𝙴 𝙳𝙴𝚇 𒆜 † 𝐄.𝐎.𝐒†</span>';
    }
  }

  // ==========================================
  // INITIALISATION
  // ==========================================

  updateInterface();

});
